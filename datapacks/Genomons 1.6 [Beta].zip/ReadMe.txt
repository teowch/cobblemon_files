Genomons liscence: CC-BY-NC-ND-4.0

Credits: 
Bwavii
Gesteyy
Cumulo
Gigdeng
Bob12521
AGA
Deli
Pohello
Allone

Donors:
Wither_Scout
Kizuato~Glitch
morty134